# Questions

## Question2

```
1 threads run
result:  17.01020302298979913758
ref: 1.70097775999999996088e+01
time: 21.71941078800000113347
2 threads run
ERROR: you should get pi, but got: 8.50612913149387139811
4 threads run
ERROR: you should get pi, but got: 4.25288825574711193411
8 threads run
ERROR: you should get pi, but got: 2.12751305787248679025
12 threads run
ERROR: you should get pi, but got: 1.41892721858107284660
16 threads run
ERROR: you should get pi, but got: 1.06412453893587555243
24 threads run
ERROR: you should get pi, but got: 0.70938827929061176736
32 threads run
result:  17.00590786299409273852
ref: 1.70097775999999996088e+01
time: 0.97381606499999995297
40 threads run
result:  17.00655640299344284472
ref: 1.70097775999999996088e+01
time: 0.66977343199999994638
48 threads run
result:  17.00600668299399131911
ref: 1.70097775999999996088e+01
time: 0.51799316800000005934
```

- Why is unsuccessful for thread 2, 4, 8, 12, 16, 24

